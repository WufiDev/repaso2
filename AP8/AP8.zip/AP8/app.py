from tiendalibros.view.console import UIConsola

if __name__ == "__main__":
    consola = UIConsola()
    consola.ejecutar_app()
