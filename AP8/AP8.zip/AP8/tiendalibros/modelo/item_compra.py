class ItemCompra:
    pass
