from tiendalibros.modelo.libro_error import LibroError


class LibroAgotadoError(LibroError):
    pass

    # Defina metodo inicializador

    # Defina metodo especial
